/*

	This class provide Object for which can be exloaded
	for more inforamtion about all function look to cpp file

	
*/

#pragma once
#include "Objects.h"
#include "Sprite.h"
#include <vector>
using namespace std ;


class Bochka:public Objects
{
public:
	Bochka();
	void Draw();
};
