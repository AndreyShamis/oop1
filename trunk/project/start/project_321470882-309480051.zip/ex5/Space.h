/*

	This class provide  empty space cell
	for more inforamtion about all function look to cpp file
*/

#pragma once
#include "Objects.h"
#include "Sprite.h"
#include <vector>
using namespace std ;

class Space:public Objects
{
public:
	Space();
	void Draw();
};
