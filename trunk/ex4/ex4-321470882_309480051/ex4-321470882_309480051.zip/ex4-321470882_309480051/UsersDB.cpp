#include "UsersDB.h"

UsersDB* UsersDB::_instance = NULL;

//=============================================================================
//	singleton :: getInsatnce of sigleton
//	if object not created create him
UsersDB* UsersDB::getInstance()
{
	if(_instance == NULL)
		_instance = new UsersDB;

	return _instance;

}
//=============================================================================
void UsersDB::destroyInsatnce()
{
	if(_instance != NULL)
		delete _instance ;

}

//=============================================================================
//	Default constractor:	Loading database from txt file
UsersDB::UsersDB()
{
	if(!LoadList())
		cout << "Can not connect to DB\n";	//	load data from db to main mem
}

//=============================================================================
UsersDB::~UsersDB()
{
	_users.clear();
}

//=============================================================================
//	function to lock
//	geting username
//	return	1	if saccess / 0	not saccess /-1	some error
int UsersDB::lockUser(const string &UserName)
{
	//	call ti function which know to change lock unlock status
	return(ChangeLockStat(UserName,true));

}
//=============================================================================
//	function to unlock
//	geting username
//	return	1	if saccess / 0	not saccess /-1	some error
int UsersDB::unlockUser(const string &UserName)
{
	//	call to function which know change lock/unlock status
	return(ChangeLockStat(UserName,false));

}

//=============================================================================
//	Add user to DB. Geting strings NewUserName And Password
//	return	1	if saccess
//			0	not saccess
//			-1	some error	
int UsersDB::addUser(const string &newUName,const string &newPass)
{

	User newUser(newUName);			//	create object User
	newUser.setPass(sham(newPass));	//	set pass for him	
	
	//	check if user name or pass size smaller than 4 or user name eq to admin
	if(newUName.length()<4 || newPass.length()<4 || newUName == "admin")
		return(0);
	
	//	fin user by name
	User *user_exist = Select(newUName);
	//	if wasnt found return NULL,check and insert
	if(user_exist == NULL && Insert(newUser))
	{
		if(SaveDB())			//	save changes
			return(1);			//	if changes saccess
		else
			return(-1);			//	if fail to write changes
	}
	else
		return(0);				//	if user exest return 0

	
}

//=============================================================================
//	function to validate user
//	get username and user Password
//	return	1	if saccess
//			0	not saccess
//			-1	some error
int UsersDB::validateUser(const string &userName,const string &password)
{
	
	//	get User struct by name
	User *user = Select(userName);
	
	short int	return_flag = false;

	//	compare between Name and Password
	if(userName == ADMIN_NAME && password == ADMIN_PASS)
		return(1);
	else if(user == NULL)
		return(0);		//	if user not found
	//	compare between input data to what was found
	else if(userName == user->getName()&& userName != ADMIN_NAME)
	{	//	compare password
		if(sham(password) == user->getPass())
		{
			user->Login();		//	udpate number of incorect logins to 0
			return_flag=1;		//	if good compare return true
		}
		else
		{
			//	increase incorect login counter
			user->setIncreaseInvalidLogin();
			//	check if the counter more than 2 and lock user
			if(user->getNumberInvalidLogin()>=3)
				user->setLocked();

			return_flag=0;		//	incorect password
		}
		if(SaveDB())			//	try save changes
			return(return_flag);//	return result of validate
		else
			return(-1);			//	if write error
	}

	return(-1);
}

//=============================================================================
//	function which check if the user locked
//	function get user name
//	return true if locked and return false if not
bool UsersDB::isLocked(const string &userName)
{
	//	try find user by name
	User *user = Select(userName);
	
	//	check if found and Lock Status
	if(user != NULL && user->getLockStatus()) 	
		return(true);					//	return locked
	
	return(false);						//	return not locked

}

//=============================================================================
//	function which check if the user is admin
//	function get user name
//	return true if admin and return false if not
bool UsersDB::isAdmin(const string &userName)
{
	//	try to find user in data base
	User *user = Select(userName);
	
	//	check if the user is admin(by name) or if found and have admin stat
	if((user==NULL && userName == ADMIN_NAME) 
		|| (user!=NULL && user->getAdmin())	)
		return(true);						//	return admin

	return(false);							//	return not admin
}

//=============================================================================
//	function to remove user from db
//	get username
//	return	1	if saccess
//			0	not saccess
//			-1	some error
int UsersDB::removeUser(const string &UserName)
{
	if(Delete(UserName))
	{
		if(SaveDB())	//	if saccess write changes return 1
			return(1);

		return(-1);		//	if fail to write return -1
	}
	
	return(0);			//	if user not exist return 0

}

//=============================================================================
//	function to unlock / unlock user status
//	get username and new value 
//	return	1	if saccess
//			0	not saccess
//			-1	some error
short int UsersDB::ChangeLockStat(const string &uName,const bool &Stat)
{

	//	try to find user by name
	User *user = Select(uName);	

	if(user != NULL)			//	check if user exits
	{
		if(Stat)				//	if need to lock
			user->setLocked();	//	lock
		else
			user->setUnLocked();//	unlock
		
		if(SaveDB())			//	try to save changes
			return(1);
			
		return(-1);				//	fail write changes
	}
		
	return(0);					//	user not exist

}


//=============================================================================
//	function which reset user password to default password
//	return	1	if saccess
//			0	not saccess
//			-1	some error
int UsersDB::resetUserPassword(const string &UserName)
{	
	//	try to find user by name
	User *user = Select(UserName);
	
	if(user!= NULL)
	{
		//	reset password to default
		user->setPass(sham(DEFAULT_USER_PASSWORD));
		if(SaveDB())			//	try to write changes
			return(1);			//	return true if saccess to wtite

		return(-1);				//	error ocured in write
	}
		
	return(0);					//	user not exist


}
//=============================================================================
//	function which return in pointer reference all users 
//	also update the counter
int UsersDB::getAllUsers(int &numOfUsers,string *&users)
{
	//	get size of db
	numOfUsers = getUsersCount();
	
	//	if size  == 0 return 0 - users not found
	if(numOfUsers == 0)
		return(0);

	//	try allocate memory
	users = new(nothrow)string[numOfUsers];
	
	//	if fail allocate memory
	if(users == NULL)
		return(-1);	   //	return error

	list <User>::iterator it;				//	set iterator for for
	int i = 0;								//	counter for aaray
	for(it=_users.begin();it!=_users.end();it++)
	{
		users[i] = (*it).getName();			//	copy name
		i++;								//	increase counter
	}
	return(1);								// returnb if users was found

}

//=============================================================================
//	 Function which return all users are locked , by referense
//	and number of them also by reference
int UsersDB::getLockedUsers(int &numOfUsers,string *&users)
{
	numOfUsers = getUsersCount();			//	get number of users
	
	if(numOfUsers == 0)						//	if number of user == 0
		return(0);							//	do nothing

	users = new(nothrow)string[numOfUsers];	//	allocate memory
	
	if(users == NULL)						//	check alocating
		return(-1);

	list <User>::iterator it;				//	set iterator
	int i = 0;								//	counter
	for(it=_users.begin();it!=_users.end();it++)
	{
		if((*it).getLockStatus())			//	get status of lock
		{									//	if locked
			users[i] = (*it).getName();		//	put into array of string
			i++;
		}
	}
	numOfUsers = i;							//	reset counter
	
	return(1);

}


//=============================================================================
//	function to crypt passwords	get password
//	return crypted password
string UsersDB::sham(const string &input)
{
	//	get input string size
	int input_size = input.length();
	string str = input;
	for(int i=0;i<input_size;i++)
	{
		int val = (int)str[i];	//	convert char to int
		
		//	mathematical manipulations whith char
		val=(val*2)+1;
		val = val%(127-34);
		if(val <34)
			val+=34;
		//	convert int back to char
		str[i] = (char)val;
	}

	return(str);						//	return value
}

//=============================================================================
//	function which know insert new user into database
bool UsersDB::Insert(const User &user)
{
	_users.push_back(user);			//	insert into list

	return true;					//	every time return true but for future
}

//=============================================================================
//	return number of users counted in data base
int	UsersDB::getUsersCount()const
{
	return((int)_users.size());
}
//=============================================================================
//	Function wich deleteing user from db by user name
//	get username will be delete
//	return true if saccess and false if not
bool UsersDB::Delete(const string &usrName)
{
	User *user = Select(usrName);				//	find user by name
	if(user == NULL)							//check if found
		return(false);

	list <User>::iterator it;					//	set iterator
	for(it=_users.begin();it!=_users.end();it++)
	{	//	compres and check
		if((*it) == *user)
		{	
			//	tryng to remove
			_users.remove((*it));
			return(true);		//	if removed return true
		}
	}	
	
	return(false);				//	if not removed return false
	
}

//=============================================================================
//	Save data base from memory to data base text
bool UsersDB::SaveDB()
{
	
	ofstream	output;					//	output stream
	output.open(TEMP_DB_NAME,ios.app);	//	open file for output

	//	check if saccess to open file
	if (output.is_open()) 
	{
		list <User>::iterator it;

		for(it=_users.begin();it!=_users.end();it++)
		{
			string write = UserToString(*it);
			output << write << "\n";	//	write to output file;
		}
	
	}
	else
		return(false);						//	can not open files
	
	//	close file
	output.close();
	//	delete old db file
	remove(DEFAULT_DB_NAME);
	//	rename old db to correct db name
	rename(TEMP_DB_NAME,DEFAULT_DB_NAME);

	//	return true
	return(true);
	
}

//=============================================================================
//	 Load database from text file to main memory
bool UsersDB::LoadList()
{
	file filedb;					//	file class

	//	check if db exist
	if(!filedb.CheckDB())
	{	//	if no create and check if exist
		if(filedb.createDB() && !filedb.CheckDB())
			return(false);
	}

	ifstream myReadFile;				//	file variable
	myReadFile.open(DEFAULT_DB_NAME);	//	open file
	
	string	line_data;					//	string variable
	User	user;						//	user class
	//string	*temp		=	NULL;		//	
	char	buf[BUFFER_SIZE];			//	buffer variable
	int		numOfUsers	=	0;			//	counter
	
	if (myReadFile.is_open())			//	if file open
	{
		while (!myReadFile.eof())		//	while not end of line
		{
			//	read line
			myReadFile.getline(buf,BUFFER_SIZE);	
			if(myReadFile.fail())		//	check if success
				break;
			line_data = buf;			//	covert chars to string
			numOfUsers++;				//	increase counter
			user = dbStrToClass(line_data);	//	convert string to class
			_users.push_back(user);		//	push to list
		}
	}
	else
		return(false);

	myReadFile.close();					//	close opened file
	
	return(true);						//	if success return true

}

//=============================================================================
//	 Covert class object to string for saving in data base
string UsersDB::UserToString(const User &user)
{
	string					save_str;			// string be returned
	char inlog			=	' ';
	short int accss_t	=	0;
	

	inlog	=(char)(user.getNumberInvalidLogin()+48);	// number of invalid
														// logins
	accss_t	= getLokAdm(user.getLockStatus(),user.getAdmin()); //statuses
	//	do string
	save_str=user.getName()+PAS+
		user.getPass()+PAS+
		inlog+PAS+
		(char)(accss_t+48)+PAS;
	
	return(save_str);			//	return string
}

//=============================================================================
//	convert the lock status and admin status to ONE digit
short int UsersDB::getLokAdm(const short int &locked,
											const short int &admin)
{
/* 
	locked  admin	result
		0   0		0
		0   1		1
		1   0		2
		1   1		3
*/
	if(!locked && !admin)
		return(0);
	else if(!locked && admin)
		return(1);
	else if(locked && !admin)
		return(2);
	else if(locked && admin)
		return(3);

	return(0);
}

//=============================================================================
//	 Find user by name Return pointer to user
User *UsersDB::Select(const string &userName)
{
	User *user = NULL;			//	return variable
	list <User>::iterator it;	//	iterator
	//	strting search by name
	for(it=_users.begin();it!=_users.end();it++)
	{
		//	compare names
		if((*it).getName() == userName)
		{
			user = &(*it);
			break;
		}
	}
	
	return(user);				//	return finded
}

//=============================================================================
//	Convert string geted from data base to class
User UsersDB::dbStrToClass(const string &db_string)
{
	int start	=	0;	//for variable
	int counter =	0;	//parameter variable
	bool LockStat;		//	lock status be returned in class
	bool AdminStat;		//	admin status be retuned in class
	string data[4];		//	temp data base
	
	//	get size of string
	unsigned int str_len = db_string.length();
	for(unsigned int i=0;i<str_len;i++)
	{	//	for each character
		if(db_string[i] == PAS)	//	check if the data between 
		{	
			//	input substring to array
			data[counter] = db_string.substr(start,i-start);
			start=i+1;			//	set for next for
			counter++;			//	counter
		}
	}

	//	convert one digir to user staus lock and admin
	dbUsrTypToProg((int)((char)data[3][0])- 48,LockStat,AdminStat);
	//	create object user
	User user(data[0],data[1],(int)data[2][0]-48,LockStat,AdminStat);
	
	return(user);				//	return object

}

//=============================================================================
//	Convert the digit geted from DB to lock status and admin status
//	Get the db value in first parameter and return lock status
//	and admin status in refrenses
void UsersDB::dbUsrTypToProg(const int &inp,bool &locked,bool &admin)  const
{
/*
	locked  admin	result
		0   0		0
		0   1		1
		1   0		2
		1   1		3
*/
	switch(inp)
	{
	case 0:
		locked	=	false;
		admin	=	false;
		break;
	case 1:
		locked	=	false;
		admin	=	true;
		break;
	case 2:
		locked	=	true;
		admin	=	false;
		break;
	case 3:
		locked	=	true;
		admin	=	true;
		break;
	}
}
//=============================================================================
//=============================================================================
//=============================================================================
